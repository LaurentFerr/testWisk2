function ajouterrider() {

    ajoutlignetab();

    // selection des valeurs saisie

    var rankTab = document.getElementById("rank").value;
    var prenomTab = document.getElementById("prenom").value;
    var nomTab = document.getElementById("nom").value;
    var clubTab = document.getElementById("club").value;
    var pointsTab = document.getElementById("points").value;

    // ecriture dans le tableau

    var r = document.createTextNode(rankTab);
    document.getElementById("newrankid").appendChild(r);
    var p = document.createTextNode(prenomTab);
    document.getElementById("newprenomid").appendChild(p);
    var n = document.createTextNode(nomTab);
    document.getElementById("newnomid").appendChild(n);
    var c = document.createTextNode(clubTab);
    document.getElementById("newclubid").appendChild(c);
    var p = document.createTextNode(pointsTab);
    document.getElementById("newpointsid").appendChild(p);

    cleanid();

};

function reset() {
    document.getElementById("rank").value = "";
    document.getElementById("prenom").value = "";
    document.getElementById("nom").value = "";
    document.getElementById("club").value = "";
    document.getElementById("points").value = "";
};

function ajoutlignetab() {

    //      Creation, des elements du tableau

    var newLigne = document.createElement('tr');

    var newRank = document.createElement('td');
    var newPrenom = document.createElement('td');
    var newNom = document.createElement('td');
    var newClub = document.createElement('td');
    var newPoints = document.createElement('td');

    //      Creation des id du tableau

    newLigne.id = "newligneid";
    newRank.id = "newrankid";
    newPrenom.id = "newprenomid";
    newNom.id = "newnomid";
    newClub.id = "newclubid";
    newPoints.id = "newpointsid";

    //      Insertion des elements

    document.getElementById('tbody').appendChild(newLigne);
    document.getElementById('newligneid').appendChild(newRank);
    document.getElementById('newligneid').appendChild(newPrenom);
    document.getElementById('newligneid').appendChild(newNom);
    document.getElementById('newligneid').appendChild(newClub);
    document.getElementById('newligneid').appendChild(newPoints);

};

function cleanid() {

    document.getElementById('newligneid').id = "";
    document.getElementById('newrankid').id = "";
    document.getElementById('newprenomid').id = "";
    document.getElementById('newnomid').id = "";
    document.getElementById('newclubid').id = "";
    document.getElementById('newpointsid').id = "";

};

function bmxSet() {

    var bmxset = true;
    return bmxset;
};

function rollerSet() {

    var rollerset = true;
    return rollerset;
};

function trottSet() {

    var trottset = true;
    return trottset;
};

function juniorSet() {

    var juniorset = true;
    return juniorset;
};

function riderSet() {

    var riderset = true;
    return riderset;
};

function masterSet() {

    var masterset = true;
    return masterset;
};

//-------------------------------------------------------

$(document).ready(function () {
    $(".btn-select").each(function (e) {
        var value = $(this).find("ul li.selected").html();
        if (value != undefined) {
            $(this).find(".btn-select-input").val(value);
            $(this).find(".btn-select-value").html(value);
        }
    });
});

$(document).on('click', '.btn-select', function (e) {
    e.preventDefault();
    var ul = $(this).find("ul");
    if ($(this).hasClass("active")) {
        if (ul.find("li").is(e.target)) {
            var target = $(e.target);
            target.addClass("selected").siblings().removeClass("selected");
            var value = target.html();
            $(this).find(".btn-select-input").val(value);
            $(this).find(".btn-select-value").html(value);
        }
        ul.hide();
        $(this).removeClass("active");
    } else {
        $('.btn-select').not(this).each(function () {
            $(this).removeClass("active").find("ul").hide();
        });
        ul.slideDown(300);
        $(this).addClass("active");
    }
});

$(document).on('click', function (e) {
    var target = $(e.target).closest(".btn-select");
    if (!target.length) {
        $(".btn-select").removeClass("active").find("ul").hide();
    }
});
